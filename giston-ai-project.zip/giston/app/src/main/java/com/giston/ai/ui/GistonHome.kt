package com.giston.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Theme (colors sampled from the reference design) ----------
object GistonColors {
    val Bg = Color(0xFF0B0A1A)
    val Surface = Color(0xFF16152C)
    val Outline = Color(0xFF2E2A5C)
    val Purple = Color(0xFF7C3AED)
    val Blue = Color(0xFF5B8CFF)
    val Gold = Color(0xFFFBBF24)
    val TextDim = Color(0xFF9A98B8)
    val Gradient = Brush.horizontalGradient(listOf(Purple, Blue))
}

@Composable
fun GistonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = GistonColors.Bg,
            surface = GistonColors.Surface,
            primary = GistonColors.Purple,
            onBackground = Color.White,
            onSurface = Color.White
        ),
    ) {
        Surface(color = GistonColors.Bg, modifier = Modifier.fillMaxSize(), content = content)
    }
}

// ---------- Data ----------
data class QuickTool(val label: String, val icon: ImageVector, val route: String)

private val quickTools = listOf(
    QuickTool("Auto Edit (AI)", Icons.Default.AutoAwesome, "auto_edit"),
    QuickTool("Clipper", Icons.Default.ContentCut, "clipper"),
    QuickTool("Text to Speech", Icons.Default.RecordVoiceOver, "tts"),
    QuickTool("Captions", Icons.Default.ClosedCaption, "captions"),
    QuickTool("Effects", Icons.Default.Star, "effects"),
    QuickTool("Transitions", Icons.Default.Compare, "transitions"),
    QuickTool("Filters", Icons.Default.FilterVintage, "filters"),
    QuickTool("Adjust", Icons.Default.Tune, "adjust")
)

private val templates = listOf("Anime Edit", "Gaming Montage", "Cinematic", "Viral Reel")

// ---------- Home screen ----------
@Composable
fun GistonHomeScreen(
    onCommand: (String) -> Unit,      // text or voice transcript -> AI edit planner
    onMicClick: () -> Unit,           // start speech recognition
    onToolClick: (String) -> Unit,
    onNewProject: () -> Unit
) {
    var command by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(GistonColors.Bg)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Giston AI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Edit. Create. Automate.", fontSize = 12.sp, color = GistonColors.TextDim)
            }
            Row(
                Modifier
                    .border(1.dp, GistonColors.Outline, RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.WorkspacePremium, null, tint = GistonColors.Gold, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Pro", color = GistonColors.Gold, fontWeight = FontWeight.SemiBold)
            }
        }

        // Hero + command box
        Column(
            Modifier
                .fillMaxWidth()
                .background(GistonColors.Surface, RoundedCornerShape(20.dp))
                .border(1.dp, GistonColors.Outline, RoundedCornerShape(20.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Just Say It...", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("We'll Edit It!", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = GistonColors.Gold)
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(GistonColors.Bg, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onMicClick) {
                    Icon(Icons.Default.Mic, "Voice command", tint = GistonColors.Blue)
                }
                Box(Modifier.weight(1f)) {
                    if (command.isEmpty()) {
                        Text("\"Make me a flashy anime edit with cool effects and music\"",
                            color = GistonColors.TextDim, fontSize = 13.sp)
                    }
                    BasicTextField(
                        value = command,
                        onValueChange = { command = it },
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 13.sp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                IconButton(
                    onClick = { if (command.isNotBlank()) onCommand(command) },
                    modifier = Modifier.background(GistonColors.Gradient, RoundedCornerShape(12.dp))
                ) { Icon(Icons.Default.Send, "Send", tint = Color.White) }
            }
        }

        // Quick tools
        SectionHeader("Quick Tools")
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.height(200.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            userScrollEnabled = false
        ) {
            items(quickTools) { tool ->
                Column(
                    Modifier
                        .background(GistonColors.Surface, RoundedCornerShape(14.dp))
                        .clickable { onToolClick(tool.route) }
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(tool.icon, tool.label, tint = GistonColors.Blue)
                    Spacer(Modifier.height(6.dp))
                    Text(tool.label, fontSize = 10.sp, maxLines = 2)
                }
            }
        }

        // New project
        Box(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .background(GistonColors.Gradient, RoundedCornerShape(16.dp))
                .clickable { onNewProject() },
            contentAlignment = Alignment.Center
        ) { Text("New Project  +", fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }

        // Templates (use your own original thumbnails, not copyrighted art)
        SectionHeader("Templates")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(templates) { name ->
                Box(
                    Modifier
                        .size(width = 110.dp, height = 130.dp)
                        .background(GistonColors.Surface, RoundedCornerShape(14.dp))
                        .border(1.dp, GistonColors.Outline, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.BottomStart
                ) { Text(name, Modifier.padding(8.dp), fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("See all >", fontSize = 12.sp, color = GistonColors.TextDim)
    }
}
