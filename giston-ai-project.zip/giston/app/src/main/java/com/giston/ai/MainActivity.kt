package com.giston.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.giston.ai.ui.GistonHomeScreen
import com.giston.ai.ui.GistonTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GistonTheme {
                GistonHomeScreen(
                    onCommand = { },
                    onMicClick = { },
                    onToolClick = { },
                    onNewProject = { }
                )
            }
        }
    }
}
