package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream

class JarvisA11y : AccessibilityService() {
    companion object {
        @Volatile var inst: JarvisA11y? = null
        @Volatile var scale: Double = 1.0
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun shot(cb: (String?, String?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null, "screenshots need Android 11 or newer"); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                    if (hw == null) { cb(null, "could not read the screen"); return }
                    val sw = hw.copy(Bitmap.Config.ARGB_8888, false)
                    r.hardwareBuffer.close()
                    val s = Math.min(1.0, 1024.0 / sw.width)
                    scale = s
                    val out = if (s < 1.0) Bitmap.createScaledBitmap(sw, (sw.width * s).toInt(), (sw.height * s).toInt(), true) else sw
                    val bos = ByteArrayOutputStream()
                    out.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                    cb(Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP), null)
                } catch (ex: Exception) {
                    cb(null, ex.message ?: "screenshot error")
                }
            }
            override fun onFailure(errorCode: Int) { cb(null, "screenshot failed, code $errorCode") }
        })
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long, cb: (Boolean) -> Unit) {
        val p = Path()
        p.moveTo(x1, y1)
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        val sent = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { cb(true) }
            override fun onCancelled(d: GestureDescription?) { cb(false) }
        }, null)
        if (!sent) cb(false)
    }

    fun tap(x: Float, y: Float, cb: (Boolean) -> Unit) = swipe(x, y, x, y, 60, cb)

    fun typeText(t: String): Boolean {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, (n.text?.toString() ?: "") + t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun key(k: String): Boolean = when (k) {
        "back", "esc" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        else -> false
    }
}
