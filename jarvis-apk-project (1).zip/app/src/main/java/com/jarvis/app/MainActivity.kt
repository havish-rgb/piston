package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var sr: SpeechRecognizer? = null

    private fun js(code: String) { web.post { web.evaluateJavascript(code, null) } }
    private fun reply(id: String, o: JSONObject) {
        js("window.__native(" + JSONObject.quote(id) + "," + JSONObject.quote(o.toString()) + ")")
    }
    private fun res(ok: Boolean): JSONObject = JSONObject().put("ok", ok).put("error", if (ok) "" else "the action did not complete")
    private fun fail(msg: String): JSONObject = JSONObject().put("ok", false).put("error", msg)

    inner class STT {
        @JavascriptInterface fun start() { runOnUiThread { listen() } }
        @JavascriptInterface fun stop() { runOnUiThread { sr?.cancel() } }
    }

    inner class App {
        @JavascriptInterface fun keepAlive(on: Boolean) {
            runOnUiThread {
                val i = Intent(this@MainActivity, JarvisService::class.java)
                try {
                    if (on) {
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    } else stopService(i)
                } catch (e: Exception) {}
            }
        }

        @JavascriptInterface fun ping(title: String, text: String, ring: Boolean) {
            runOnUiThread { notifyUser(title, text, ring) }
        }

        @JavascriptInterface fun openUrl(u: String): String {
            return try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runOnUiThread { startActivity(i) }
                JSONObject().put("ok", true).put("verified", true).put("detail", "link opened").toString()
            } catch (e: Exception) {
                fail(e.message ?: "could not open link").toString()
            }
        }

        @JavascriptInterface fun openApp(name: String): String {
            val pm = packageManager
            var i: Intent? = pm.getLaunchIntentForPackage(name)
            if (i == null) {
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val ri = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
                if (ri != null) i = pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
            }
            val launch: Intent = i ?: return fail("no installed app matches " + name).toString()
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runOnUiThread { startActivity(launch) }
            return JSONObject().put("ok", true).put("verified", true).put("detail", "launch requested, the next screenshot will confirm").toString()
        }

        @JavascriptInterface fun a11y(): Boolean = JarvisA11y.inst != null

        @JavascriptInterface fun a11ySettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface fun screenshot(id: String) {
            val s = JarvisA11y.inst
            if (s == null) { reply(id, fail("Phone Control is off. Tap PHONE CONTROL SETUP and enable JARVIS")); return }
            s.shot { img, err ->
                if (img != null) reply(id, JSONObject().put("ok", true).put("verified", true).put("image", img))
                else reply(id, fail(err ?: "screenshot failed"))
            }
        }

        @JavascriptInterface fun act(id: String, json: String) {
            val s = JarvisA11y.inst
            if (s == null) { reply(id, fail("Phone Control is off. Tap PHONE CONTROL SETUP and enable JARVIS")); return }
            try {
                val b = JSONObject(json)
                val a = b.optString("action")
                val k = JarvisA11y.scale
                val x = (b.optDouble("x", 0.0) / k).toFloat()
                val y = (b.optDouble("y", 0.0) / k).toFloat()
                val x2 = (b.optDouble("x2", 0.0) / k).toFloat()
                val y2 = (b.optDouble("y2", 0.0) / k).toFloat()
                when (a) {
                    "click" -> s.tap(x, y) { ok -> reply(id, res(ok)) }
                    "swipe" -> s.swipe(x, y, x2, y2, 300) { ok -> reply(id, res(ok)) }
                    "type" -> reply(id, res(s.typeText(b.optString("text"))))
                    "key" -> reply(id, res(s.key(b.optString("key"))))
                    "wait" -> {
                        val ms = (Math.min(b.optDouble("seconds", 2.0), 10.0) * 1000).toLong()
                        Handler(Looper.getMainLooper()).postDelayed({ reply(id, res(true)) }, ms)
                    }
                    else -> reply(id, fail("unsupported phone action: " + a))
                }
            } catch (e: Exception) {
                reply(id, fail(e.message ?: "action error"))
            }
        }

        @JavascriptInterface fun recent(secs: Int): String {
            return try {
                val since = System.currentTimeMillis() / 1000 - secs
                val c = contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE),
                    MediaStore.Video.Media.DATE_ADDED + " >= ? AND " + MediaStore.Video.Media.SIZE + " > 0",
                    arrayOf(since.toString()),
                    MediaStore.Video.Media.DATE_ADDED + " DESC"
                )
                val names = ArrayList<String>()
                c?.use { while (it.moveToNext() && names.size < 5) names.add(it.getString(0) + " (" + (it.getLong(1) / 1024) + " KB)") }
                JSONObject().put("ok", true).put("verified", names.isNotEmpty())
                    .put("detail", if (names.isEmpty()) "no new videos in the gallery" else names.joinToString(", ")).toString()
            } catch (e: Exception) {
                fail("cannot read the gallery: " + e.message).toString()
            }
        }
    }

    private fun notifyUser(title: String, text: String, ring: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("jarvis_alert", "JARVIS alerts", NotificationManager.IMPORTANCE_HIGH)
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jarvis_alert") else Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text)
            .setContentIntent(pi).setAutoCancel(true)
        nm.notify((System.currentTimeMillis() % 100000).toInt(), b.build())
        if (ring) {
            try {
                val r = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
                r.play()
                Handler(Looper.getMainLooper()).postDelayed({ r.stop() }, 5000)
            } catch (e: Exception) {}
        }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            js("window.__sttErr && window.__sttErr('not-allowed')"); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.__sttErr && window.__sttErr('service-not-allowed')"); return
        }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) js("window.__sttResult(" + JSONObject.quote(t) + ")")
                js("window.__sttEnd && window.__sttEnd()")
            }
            override fun onError(e: Int) { js("window.__sttEnd && window.__sttEnd()") }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        sr!!.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            for (p in arrayOf("android.permission.POST_NOTIFICATIONS", "android.permission.READ_MEDIA_VIDEO"))
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
        }
        web.addJavascriptInterface(STT(), "AndroidSTT")
        web.addJavascriptInterface(App(), "AndroidApp")
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) { r.grant(r.resources) }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onPause() { super.onPause(); web.resumeTimers() }
    override fun onStop() { super.onStop(); web.resumeTimers() }
    override fun onDestroy() { sr?.destroy(); super.onDestroy() }
}
